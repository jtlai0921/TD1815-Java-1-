public class ForeachDemo {

	public static void main(String[] args) {
		// 定义并初始化数组，使用静态初始化
		int[] a = { 5, 7, 20 };

		// 使用foreach语句遍历输出a数组中的元素
		System.out.println("数组a中的元素是：");
		for (int e : a) {
			System.out.println(e);
		}
	}

}
