public class ContinueDemo {

	public static void main(String[] args) {
		for (int i = 1; i <= 10; i++) {			
			if (i == 5) {
				System.out.println("找到目标,继续循环！");
				// 跳出本次循环，进入下一次循环
				continue;
			}
			System.out.println(i);// 打印当前的i值
		}
	}

}
