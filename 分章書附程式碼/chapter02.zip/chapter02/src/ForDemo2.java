public class ForDemo2 {

	public static void main(String[] args) {
		// 使用for循环求1~100的和
		int sum = 0;
		for (int i = 1; i <= 100; i++) {
			sum += i;
		}
		System.out.println("1~100的和是：" + sum);
	}
}
