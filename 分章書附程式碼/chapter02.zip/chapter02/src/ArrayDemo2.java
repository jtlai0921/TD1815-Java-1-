public class ArrayDemo2 {

	public static void main(String[] args) {
		// 定义并初始化数组，使用静态初始化
		int[] a = { 5, 7, 20 };
		// 定义并初始化数组，使用动态初始化
		int[] b = new int[4];
		for (int i = 0; i < b.length; i++) {
			b[i] = i + 1;
		}
		// 循环输出a数组的元素
		System.out.println("数组a中的元素是：");
		for (int i = 0, len = a.length; i < len; i++) {
			System.out.print(a[i] + " ");
		}
		System.out.println();
		// 输出b数组的长度
		System.out.println("b数组的长度为：" + b.length);
		System.out.println("数组b中的元素是：");
		// 循环输出b数组的元素
		for (int i = 0, len = b.length; i < len; i++) {
			System.out.print(b[i] + " ");
		}
		System.out.println();
		// 因为a是int[]类型，b也是int[]类型，所以可以将a的值赋给b。
		// 也就是让b引用指向a引用指向的数组
		b = a;
		// 再次输出b数组的长度
		System.out.println("b数组的长度为：" + b.length);
	}
}
