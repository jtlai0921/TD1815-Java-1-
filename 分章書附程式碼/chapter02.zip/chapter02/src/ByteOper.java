public class ByteOper {

	public static void main(String[] args) {
		int a = 0b00101010;
		int b = 0b00001111;
		// 按位与
		System.out.println(Integer.toBinaryString(a & b));
		// 按位或
		System.out.println(Integer.toBinaryString(a | b));
		//按位异或
		System.out.println(Integer.toBinaryString(a^b ));
		
		int c=0b11111000000000000000000000000000;
		//左移
		System.out.println(Integer.toBinaryString(c<<1 ));
		//右移
		System.out.println(Integer.toBinaryString(c>>1));
		//无符号右移
		System.out.println(Integer.toBinaryString(c>>>1));
	}
}
