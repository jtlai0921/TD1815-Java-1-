public class SwitchDemo1 {

	public static void main(String[] args) {
		int g = 67;
		// 使用switch 判断g的等级
		switch (g / 10) {
		case 10:
		case 9:
			System.out.println("优秀");
			break;
		case 8:
			System.out.println("良好");
			break;
		case 7:
			System.out.println("中等");
			break;
		case 6:
			System.out.println("及格");
			break;
		default:
			System.out.println("不及格");
		}
	}

}
