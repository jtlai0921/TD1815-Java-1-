public class ReturnDemo {

	public static void main(String[] args) {
		// 一个简单的for循环
		for (int i = 0; i < 3; i++) {
			System.out.println("i的值是" + i);
			if (i == 5) {
				//返回，结束main方法
				return;
			}
			System.out.println("return后的输出语句");
		}
	}

}
