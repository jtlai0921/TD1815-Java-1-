
public class ForDemo3 {

	public static void main(String[] args) {
		// 嵌套的for循环打印九九乘法表
		//第一个for控制行
		for (int i = 1; i <= 9; i++) {
			//第二个for控制列，即每行中输出的算式
			for (int j = 1; j <= i; j++) {
				// 输出j*i=n格式,例如2*3=6
				System.out.print(j + "*" + i + "=" + i * j + " ");
			}
			// 换行
			System.out.println();
		}
	}
}
