public class ValueOper {

	public static void main(String[] args) {
		int a = 8;
		int b = 3;
		System.out.println(a += b);
		System.out.println(a -= b);
		System.out.println(a *= b);
		System.out.println(a /= b);
		System.out.println(a %= b);
		System.out.println(a &= b);
		System.out.println(a |= b);
		System.out.println(a <<= b);
		System.out.println(a >>= b);
		System.out.println(a >>>= b);
	}

}
