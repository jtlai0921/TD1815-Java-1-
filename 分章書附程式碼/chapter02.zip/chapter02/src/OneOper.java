/**
 * @公司 青软实训QST
 * @作者 zhaokl
 * @日期 2014年9月15日 下午3:09:58
 */

public class OneOper {

	public static void main(String[] args) {
		int a = 5;
		int b = ++a + 8;// a先自增变为6，再与8相加，最后b的值是14
		System.out.println("b的值是：" + b);
		int c = a++;
		System.out.println("c的值是：" + c);
		System.out.println("a的值是：" + a);
		int d = 10;
		System.out.println("前缀自减--d的值是：" + --d);
		System.out.println("当前d的值是：" + d);
		System.out.println("后缀自减d--的值是：" + d--);
		System.out.println("当前d的值是：" + d);
		boolean flag = true;
		System.out.println("逻辑非：" + !flag);
		int t = 10;// 二进制是1010
		// Integer.toBinaryString()以二进制形式输出一个整数
		System.out.println("整数10的二进制表示：" + Integer.toBinaryString(t));
		// 按位非后的二进制是11111111111111111111111111110101
		System.out.println("按位非的二进制表示：" + Integer.toBinaryString(~t));
		// 按位非后的数值是-11,因为11111111111111111111111111110101是-11的补码
		System.out.println("按位非的十进制表示：" + ~t);
	}

}
