public class VarScope {
	public static void main(String[] args) {
		// 变量a的作用域是main()方法体内
		int a = 10;
		{
			// 变量b的作用域是当前程序块的两个大括号中｛｝
			int b = a * a;
			// 此处变量a和变量b都在作用域范围内，都可以访问
			System.out.println("a=" + a + ",b=" + b);
		}
		// 此处变量a在作用域范围内，可以访问
		System.out.println("a=" + a);
		// 错误，此处变量b已经不在作用域范围内，不可以访问
		// System.out.println("b=" + b);
	}
}
