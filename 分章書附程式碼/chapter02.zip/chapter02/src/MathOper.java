/**   
 * @公司   青软实训QST
 * @作者 zhaokl
 * @日期 2014年9月15日 下午4:46:59 
 */


public class MathOper {

	public static void main(String[] args) {
		int a = 5;
		int b = 3;
		// c的值为8
		int c = a + b;
		System.out.println(c);
		// 字符串连接
		String s1 = "abc";
		String s2 = "efg";

		// s3的值为"abcefg"
		String s3 = s1 + s2;
		System.out.println(s3);
		// 两个数相减，结果为2
		System.out.println(a - b);
		// 两个数相乘，结果为15
		System.out.println(a * b);
		// 两个整数相除，结果为1
		System.out.println(a / b);
		// 两个浮点数相除，结果为1.7
		System.out.println(5.1 / 3);
		// 两个整数取余，结果为2
		System.out.println(a % b);
		// 两个浮点数取余，结果为2.1
		System.out.println(5.2 % 3.1);
		//正浮点数除以0，结果为Infinity
		System.out.println(3.1/0);
		//负浮点数除以0，结果为-Infinity
		System.out.println(-8.8/0);
		//正浮点数对0取余，结果为NaN
		System.out.println(5.1%0);
		//负浮点数对0取余，结果为NaN
		System.out.println(6.6%0);
		//整数除以0,将引发异常
		System.out.println(3/0);
	}

}
