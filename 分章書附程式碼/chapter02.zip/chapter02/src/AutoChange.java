public class AutoChange {

	public static void main(String[] args) {
		byte b = 7;
		char c = 'A';
		int a = 10;
		long l = 789L;
		float f = 3.14f;//
		double d = 5.3d;

		int i1 = a + c; // 字符型变量c自动转换为整型，参加加法运算
		System.out.println("i1=" + i1);
		long l1 = l - i1; // 整型变量i1自动转换为长整型，参加减法运算
		System.out.println("l1=" + l1);
		float f1 = b * f; // 字节型变量b自动转换为浮点型，参加乘法运算
		System.out.println("f1=" + f1);
		double d1 = d / a; // 整型变量a自动转换为双精度，参加除法运算
		System.out.println("d1=" + d1);

		int i2 = (int) f1;// 将浮点型变量f1强制类型转换为整数
		System.out.println("i2=" + i2);
		char c2 = (char) (l / a);// 整型变量a自动类型转换为长整型后参加除法运算，算出的长整型结果再强制类型转换为字符型
		System.out.println("c2=" + c2);
	}
}
