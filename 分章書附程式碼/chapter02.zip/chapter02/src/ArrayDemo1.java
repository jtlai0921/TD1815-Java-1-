public class ArrayDemo1 {
	public static void main(String args[]) {
		// 声明一个整型数组a
		int[] a;
		// 给数组a分配存储空间：10*4个字节
		a = new int[10];
		// 定义一个长度为10的双精度浮点型数组
		double[] b = new double[10];
		// 定义一个长度为100的字符型数组c
		char[] c = new char[100];
		// 定义一个长度为20的布尔型数组
		boolean[] d = new boolean[20];
		//定义一个长度为5的字符串数组
		String[] s=new String[5];
		/* 下面输出各数组的数组名，注意输出的内容 */
		System.out.println(a);// 输出数组地址
		System.out.println(b);// 输出数组地址
		System.out.println(c);//输出字符数组中的内容
		System.out.println(d);//输出数组地址
		System.out.println(s);//输出数组地址
		System.out.println("*****************");
		/* 下面输出各数组中第一个元素的值，注意输出的内容 */
		System.out.println(a[0]);
		System.out.println(b[0]);
		System.out.println(c[0]);
		System.out.println(d[0]);
		System.out.println(s[0]);
		System.out.println("*****************");
		/* 下面输出各数组的长度 */
		System.out.println("a.length=" + a.length);
		System.out.println("b.length=" + b.length);
		System.out.println("c.length=" + c.length);
		System.out.println("d.length=" + d.length);
		System.out.println("s.length=" + s.length);
	}
}
