
public class VarValue {

	public static void main(String[] args) {
		//声明变量a并赋初值
		int a=10;
		//声明变量b
		int b;
		//a已经有值，可以使用
		System.out.println("a="+a);
		//错误，b还没有值，不能使用
		// System.out.println("b="+b);
		//在使用之前先给b赋值
		b=20;
		//正确，b有值后可以使用
		System.out.println("b="+b);
	}

}
