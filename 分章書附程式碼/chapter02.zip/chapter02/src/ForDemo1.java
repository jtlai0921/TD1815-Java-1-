public class ForDemo1 {

	public static void main(String[] args) {
		// 循环的初始化，循环条件，循环迭代语句都在下面一行
		for (int count = 1; count <= 10; count++) {
			System.out.println(count);
		}
		System.out.println("循环结束!");
	}

}
