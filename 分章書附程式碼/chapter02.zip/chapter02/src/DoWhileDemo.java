public class DoWhileDemo {

	public static void main(String[] args) {
		// 使用do-while循环求1~100的和
		int sum = 0;
		int i = 1;
		do {
			sum += i;
			i++;
		} while (i <= 100);
		System.out.println("1~100的和是：" + sum);
	}

}
