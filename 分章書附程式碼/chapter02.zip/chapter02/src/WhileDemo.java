public class WhileDemo {

	public static void main(String[] args) {
		// 使用while循环求1~100的和
		int sum = 0;
		int i = 1;
		while (i <= 100) {
			sum += i;
			i++;
		}
		System.out.println("1~100的和是：" + sum);
	}

}
