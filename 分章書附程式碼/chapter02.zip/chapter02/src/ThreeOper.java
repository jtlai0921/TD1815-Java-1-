public class ThreeOper {

	public static void main(String[] args) {
		int a = 56;
		int b = 45;
		int c = 78;
		System.out.println("a > b ? a : b = " + (a > b ? a : b));
		System.out.println("a > c ? a : c = " + (a > c ? a : c));
	}

}
