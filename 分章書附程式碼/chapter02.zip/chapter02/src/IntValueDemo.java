/**
 * @公司 青软实训QST
 * @作者 zhaokl
 * @日期 2014年9月15日 下午2:30:07
 */

public class IntValueDemo {

	public static void main(String[] args) {
		// 二进制数
		int a = 0b1001;
		System.out.println("二进制数0b1001的值是：" + a);
		// 八进制数
		int b = 071;
		System.out.println("八进制数071的值是：" + b);
		// 十进制数
		int c = 19;
		System.out.println("十进制数19的值是：" + c);
		// Integer.toBinaryString()方法将一个整数以二进制形式输出
		System.out.println("19的二进制表示是：" + Integer.toBinaryString(c));
		// 十六进制数
		int d = 0xFE;
		System.out.println("十六进制数0xFE的值是：" + d);
		System.out.println("十六进制数0xFE的二进制表示是：" + Integer.toBinaryString(d));
		// 负数以补码形式存储
		int e = -19;
		System.out.println("-19的二进制表示是：" + Integer.toBinaryString(e));
	}

}
