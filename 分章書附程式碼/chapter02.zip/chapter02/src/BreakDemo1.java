public class BreakDemo1 {

	public static void main(String[] args) {
		for (int i = 1; i <= 10; i++) {			
			if (i == 5) {
				System.out.println("找到目标,结束循环！");
				// 终止循环
				break;
			}
			System.out.println(i);// 打印当前的i值
		}

	}

}
