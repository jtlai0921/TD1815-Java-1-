public class IfDemo {

	public static void main(String[] args) {
		int g = 67;
		// 判断g是否是负数
		if (g < 0) {
			System.out.println("负数");
		}

		// 判断g是偶数还是奇数
		if (g % 2 == 0) {
			System.out.println("偶数");
		} else {
			System.out.println("奇数");
		}

		// 判断g的等级
		if (g >= 90) {
			System.out.println("优秀");
		} else if (g >= 80) {
			System.out.println("良好");
		} else if (g >= 70) {
			System.out.println("中等");
		} else if (g >= 60) {
			System.out.println("及格");
		} else {
			System.out.println("不及格");
		}
	}

}
