package com.qst.chapter06;

//抽象类
public abstract class Animal {
	private String name;

	public Animal() {

	}

	public Animal(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// 抽象方法，行动
	public abstract void action();

	// 抽象方法，叫
	public abstract void call();

}
