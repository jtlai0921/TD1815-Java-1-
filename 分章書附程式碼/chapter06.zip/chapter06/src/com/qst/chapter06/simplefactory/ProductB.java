package com.qst.chapter06.simplefactory;

//ProductB实现IProduct接口
public class ProductB implements IProduct {
	// 实现接口中的抽象方法
	public String get() {
		return "ProductB生产完毕！";
	}
}
