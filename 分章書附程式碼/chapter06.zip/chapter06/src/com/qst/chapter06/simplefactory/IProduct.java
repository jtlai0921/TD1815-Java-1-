package com.qst.chapter06.simplefactory;
/*
 * 产品的抽象接口
 */
public interface IProduct {
	//获取产品
	String get();
}
