package com.qst.chapter06.simplefactory;

//工厂类
public class Factory {
	// 根据客户要求生产产品
	public static IProduct getProduct(String name) {
		IProduct p = null;
		if (name.equals("ProductA")) {
			p = new ProductA();
		} else if (name.equals("ProductB")) {
			p = new ProductB();
		}
		return p;
	}

}
