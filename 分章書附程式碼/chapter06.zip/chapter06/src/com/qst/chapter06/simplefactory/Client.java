package com.qst.chapter06.simplefactory;

//客户测试类
public class Client {

	public static void main(String[] args) {
		// 客户要求生产ProductA
		IProduct p = Factory.getProduct("ProductA");
		System.out.println(p.get());
		// 客户要求生产ProductB
		p = Factory.getProduct("ProductB");
		System.out.println(p.get());
	}

}
