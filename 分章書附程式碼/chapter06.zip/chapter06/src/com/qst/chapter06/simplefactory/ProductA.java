package com.qst.chapter06.simplefactory;
//ProductA实现IProduct接口
public class ProductA implements IProduct{
	//实现接口中的抽象方法
	public String get() {
		return "ProductA生产完毕！";
	}
}
