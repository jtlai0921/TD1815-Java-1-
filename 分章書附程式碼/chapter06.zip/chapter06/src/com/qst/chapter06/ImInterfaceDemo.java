package com.qst.chapter06;

//实现接口
public class ImInterfaceDemo implements MyInterface {

	// 定义个一个字符串数组，长度是接口中定义的常量MAX_SIZE
	private String[] msgs = new String[MyInterface.MAX_SIZE];
	// 记录消息个数
	private int num = 0;

	// 实现接口中的方法
	public void delMsg() {
		if (num <= 0) {
			System.out.println("消息队列已空，删除失败！");
		} else {
			// 删除消息，num数量减1
			msgs[--num] = null;
		}
	}

	// 实现接口中的方法
	public void addMsg(String msg) {
		if (num >= MyInterface.MAX_SIZE) {
			System.out.println("消息队列已满，添加失败！");
		} else {
			// 将消息添加到字符串数组中，num数量加1
			msgs[num++] = msg;
		}
	}

	// 定义一个实现类自己的方法
	public void showMsg() {
		// 输出消息队列中的信息
		for (int i = 0; i < num; i++) {
			System.out.println(msgs[i]);
		}
	}

	public static void main(String[] args) {
		// 实例化一个接口实现类的对象，并将其赋值给一个接口变量引用
		MyInterface mi = new ImInterfaceDemo();
		// 调用接口的默认方法，默认方法必须通过实例对象来调用
		mi.print("张三", "李四", "王五");
		// 调用接口的类方法，直接通过“接口名.类方法()”来调用
		System.out.println(MyInterface.staticTest());

		System.out.println("------------------------");

		// 实例化接口实现类
		ImInterfaceDemo ifd = new ImInterfaceDemo();
		// 添加信息
		ifd.addMsg("Java 8应用开发");
		ifd.addMsg("欢迎来到青软实训");
		ifd.addMsg("My name's zhaokel");
		ifd.addMsg("这是一个测试");
		// 输出信息
		ifd.showMsg();

		System.out.println("------------------------");

		// 删除一个信息
		ifd.delMsg();
		System.out.println("删除一个数据后，剩下的信息是：");
		ifd.showMsg();
	}

}
