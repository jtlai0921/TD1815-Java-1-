package com.qst.chapter06;

public class AbstractDemo {

	public static void main(String[] args) {
		// 声明一个抽象类变量
		Animal a;
		// 不能直接实例化一个抽象类，但抽象类变量可以指向其子类
		a = new Horse("马儿");
		a.action();
		a.call();
		a = new Bird("鸟儿");
		a.action();
		a.call();
	}

}
