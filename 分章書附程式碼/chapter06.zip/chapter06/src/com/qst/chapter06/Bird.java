package com.qst.chapter06;

//鸟，继承Animal抽象类
public class Bird extends Animal {
	public Bird() {

	}

	public Bird(String name) {
		super(name);
	}

	// 重写Animal抽象类中的action()抽象方法
	public void action() {
		System.out.println(this.getName() + "翅膀飞！");
	}

	// 重写Animal抽象类中的call()抽象方法
	public void call() {
		System.out.println(this.getName() + "叽喳叫！");
	}
}
