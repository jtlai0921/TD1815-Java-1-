package com.qst.chapter06;

//马，继承Animal抽象类
public class Horse extends Animal {
	public Horse() {
	}

	public Horse(String name) {
		super(name);
	}

	// 重写Animal抽象类中的action()抽象方法
	public void action() {
		System.out.println(this.getName() + "四条腿奔跑！");
	}

	// 重写Animal抽象类中的call()抽象方法
	public void call() {
		System.out.println(this.getName() + "长啸！");
	}
}
