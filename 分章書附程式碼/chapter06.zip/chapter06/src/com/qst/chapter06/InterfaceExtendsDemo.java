package com.qst.chapter06;

//接口的继承
//第一个接口
interface InterfaceA {
	int V_A = 10;

	void testA();
}

// 第二个接口
interface InterfaceB {
	int V_B = 20;

	void testB();
}

// 第三个接口
interface InterfaceC extends InterfaceA, InterfaceB {
	int V_C = 30;

	void testC();
}

// 实现第三个接口
public class InterfaceExtendsDemo implements InterfaceC {
	// 实现三个抽象方法
	public void testA() {
		System.out.println("testA()方法");

	}

	public void testB() {
		System.out.println("testB()方法");

	}

	public void testC() {
		System.out.println("testC()方法");

	}

	public static void main(String[] args) {
		// 使用第三个接口可以直接访问V_A、V_B和V_C常量
		System.out.println(InterfaceC.V_A);
		System.out.println(InterfaceC.V_B);
		System.out.println(InterfaceC.V_C);
		// 声明第三个接口变量，并指向其实现类的实例对象
		InterfaceC ic = new InterfaceExtendsDemo();
		// 调用接口中的方法
		ic.testA();
		ic.testB();
		ic.testC();
	}

}
