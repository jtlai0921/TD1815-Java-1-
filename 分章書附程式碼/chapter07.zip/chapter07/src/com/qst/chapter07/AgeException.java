package com.qst.chapter07;

public class AgeException extends Exception {

	public AgeException() {

	}

	public AgeException(String msg) {
		super(msg);
	}
	
}
