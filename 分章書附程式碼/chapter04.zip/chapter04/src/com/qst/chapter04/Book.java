package com.qst.chapter04;

public class Book {
	// ����
	private String bookName;// ����
	private double price;// �۸�
	private String publisher;// ������
	private String isbn;// ISBN��

	// Ĭ�Ϲ��췽��
	public Book() {

	}

	// ���ع��췽��
	public Book(String bookName, double price, String publisher, String isbn) {
		this.bookName = bookName;
		this.price = price;
		this.publisher = publisher;
		this.isbn = isbn;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	// ��дtoString()����
//	public String toString() {
//		return this.bookName + ",��" + this.price + "," + this.publisher
//				+ ",ISBN:" + this.isbn;
//	}
}
