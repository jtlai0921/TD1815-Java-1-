package com.qst.chapter04;

public class BoxingUnBoxingDemo {

	public static void main(String[] args) {
		int i = 10;
		// �Զ�װ��
		Integer obj = i + 5;
		Double dobj = 4.5;
		Boolean bobj = false;
		System.out.println("obj=" + obj+",dobj="+dobj+",bobj="+bobj);
		// �Զ�����
		int a = obj;
		double d=dobj;
		boolean b=bobj;
		System.out.println("a=" + a+",d="+d+",b="+b);

	}

}
