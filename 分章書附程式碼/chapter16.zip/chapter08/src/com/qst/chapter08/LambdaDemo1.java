package com.qst.chapter08;

public class LambdaDemo1 {
	

	public static void main(String[] args) {
      
	}

}
