package p1;
class MyClass2 {
	public void func1() {
		System.out.println("func1 of MyClass2");
	}
}
