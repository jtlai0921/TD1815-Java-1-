package com.qst.dms.gather;

//数据分析接口
public interface IDataAnalyse {
	// 进行数据匹配
	Object[] matchData();
}
