package com.qst.dms.gather;

import com.qst.dms.entity.DataBase;
import com.qst.dms.entity.LogRec;
import com.qst.dms.entity.MatchedTransport;
import com.qst.dms.entity.Transport;

//物流分析类，继承DataFilter抽象类，实现数据分析接口
public class TransportAnalyse extends DataFilter implements IDataAnalyse {
	// 发货集合
	private Transport[] transSends;
	// 送货集合
	private Transport[] transIngs;
	// 已签收集合
	private Transport[] transRecs;

	// 构造方法
	public TransportAnalyse() {
	}

	public TransportAnalyse(Transport[] trans) {
		super(trans);
	}

	// 实现DataFilter抽象类中的过滤抽象方法
	public void doFilter() {
		// 获取数据集合
		Transport[] trans = (Transport[]) this.getDatas();
		// 根据物流状态统计不同状态的物流个数
		int numSend = 0;
		int numTran = 0;
		int numRec = 0;
		// 遍历统计
		for (Transport tran : trans) {
			if (tran.getTransportType() == Transport.SENDDING) {
				numSend++;
			} else if (tran.getTransportType() == Transport.TRANSPORTING) {
				numTran++;
			} else if (tran.getTransportType() == Transport.RECIEVED) {
				numRec++;
			}
		}
		// 创建不同状态的物流数组
		transSends = new Transport[numSend];
		transIngs = new Transport[numTran];
		transRecs = new Transport[numRec];
		// 数组下标记录
		int indexSend = 0;
		int indexTran = 0;
		int indexRec = 0;
		// 遍历，对物流数据进行过滤，根据物流状态分别放在不同的数组中
		for (Transport tran : trans) {
			if (tran.getTransportType() == Transport.SENDDING) {
				transSends[indexSend++] = tran;
			} else if (tran.getTransportType() == Transport.TRANSPORTING) {
				transIngs[indexTran++] = tran;
			} else if (tran.getTransportType() == Transport.RECIEVED) {
				transRecs[indexRec++] = tran;
			}
		}

	}

	// 实现IDataAnalyse接口中数据分析方法
	public Object[] matchData() {
		// 创建物流匹配数组
		MatchedTransport[] matchTrans = new MatchedTransport[transSends.length];
		// 日志匹配数组下标记录
		int index = 0;
		// 数据匹配分析
		for (Transport send : transSends) {
			for (Transport tran : transIngs) {
				for (Transport rec : transRecs) {
					if ((send.getReciver().equals(tran.getReciver()))
							&& (send.getReciver().equals(rec.getReciver()))
							&& (tran.getType()!=DataBase.MATHCH)
							&& (rec.getType()!=DataBase.MATHCH)) {
						// 修改物流状态类型为“匹配”
						send.setType(DataBase.MATHCH);
						tran.setType(DataBase.MATHCH);
						rec.setType(DataBase.MATHCH);
						// 添加到匹配数组中
						matchTrans[index++] = new MatchedTransport(send, tran,
								rec);
					}
				}
			}
		}
		return matchTrans;
	}
}
