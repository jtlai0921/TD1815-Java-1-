package com.qst.dms.gather;

import com.qst.dms.entity.DataBase;
import com.qst.dms.entity.LogRec;
import com.qst.dms.entity.MatchedLogRec;

//日志分析类，继承DataFilter抽象类，实现数据分析接口
public class LogRecAnalyse extends DataFilter implements IDataAnalyse {
	// “登录”集合
	private LogRec[] logIns;
	// “登出”集合
	private LogRec[] logOuts;

	// 构造方法
	public LogRecAnalyse() {
	}

	public LogRecAnalyse(LogRec[] logRecs) {
		super(logRecs);
	}

	// 实现DataFilter抽象类中的过滤抽象方法
	public void doFilter() {
		// 获取数据集合
		LogRec[] logs = (LogRec[]) this.getDatas();
		// 根据日志登录状态统计不同状态的日志个数
		int numIn = 0;
		int numOut = 0;
		// 遍历统计
		for (LogRec rec : logs) {
			if (rec.getLogType() == LogRec.LOG_IN) {
				numIn++;
			} else if (rec.getLogType() == LogRec.LOG_OUT) {
				numOut++;
			}
		}
		// 创建登录、登出数组
		logIns = new LogRec[numIn];
		logOuts = new LogRec[numOut];
		// 数组下标记录
		int indexIn = 0;
		int indexOut = 0;
		// 遍历，对日志数据进行过滤，根据日志登录状态分别放在不同的数组中
		for (LogRec rec : logs) {
			if (rec.getLogType() == LogRec.LOG_IN) {
				// 添加到“登录”日志数组中，indexIn下标增1
				logIns[indexIn++] = rec;
			} else if (rec.getLogType() == LogRec.LOG_OUT) {
				// 添加到“登出”日志数组中,indexOut下标增1
				logOuts[indexOut++] = rec;
			}
		}

	}

	// 实现IDataAnalyse接口中数据分析方法
	public Object[] matchData() {
		// 创建日志匹配数组
		MatchedLogRec[] matchLogs = new MatchedLogRec[logIns.length];
		// 日志匹配数组下标记录
		int index = 0;
		// 数据匹配分析
		for (LogRec in : logIns) {
			for (LogRec out : logOuts) {
				if ((in.getUser().equals(out.getUser()))
						&& (in.getIp().equals(out.getIp()))
						&& out.getType()!=DataBase.MATHCH) {
					//修改in和out日志状态类型为“匹配”
					in.setType(DataBase.MATHCH);
					out.setType(DataBase.MATHCH);
					//添加到匹配数组中
					matchLogs[index++] = new MatchedLogRec(in, out);
				}
			}
		}
		return matchLogs;
	}
}
