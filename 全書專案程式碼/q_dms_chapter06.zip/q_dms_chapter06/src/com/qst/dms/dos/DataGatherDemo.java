package com.qst.dms.dos;

import com.qst.dms.entity.LogRec;
import com.qst.dms.entity.MatchedLogRec;
import com.qst.dms.entity.MatchedTransport;
import com.qst.dms.entity.Transport;
import com.qst.dms.gather.LogRecAnalyse;
import com.qst.dms.gather.TransportAnalyse;
import com.qst.dms.service.LogRecService;
import com.qst.dms.service.TransportService;

//数据分析测试
public class DataGatherDemo {

	public static void main(String[] args) {
		// 创建一个日志业务类
		LogRecService logService = new LogRecService();
		// 创建一个日志对象数组，用于存放采集的三个日志信息
		LogRec[] logs = new LogRec[3];
		for (int i = 0; i < logs.length; i++) {
			System.out.println("第" + (i + 1) + "个日志数据采集：");
			logs[i] = logService.inputLog();
		}
		// 创建日志数据分析对象
		LogRecAnalyse logAn = new LogRecAnalyse(logs);
		// 日志数据过滤
		logAn.doFilter();
		// 日志数据分析
		Object[] objs = logAn.matchData();
		// 判断objs数组是否是配置日志数组
		if (objs instanceof MatchedLogRec[]) {
			// 将对象数组强制类型转换成配置日志数组
			MatchedLogRec[] matchLogs = (MatchedLogRec[]) objs;
			// 输出匹配的日志信息
			logService.showMatchLog(matchLogs);
		}
		// 创建一个物流业务类
		TransportService tranService = new TransportService();
		// 创建一个物流对象数组，用于存放采集的四个物流信息
		Transport[] transports = new Transport[4];
		for (int i = 0; i < transports.length; i++) {
			System.out.println("第" + (i + 1) + "个物流数据采集：");
			transports[i] = tranService.inputTransport();
		}
		// 创建物流数据分析对象
		TransportAnalyse transAn = new TransportAnalyse(transports);
		// 物流数据过滤
		transAn.doFilter();
		// 物流数据分析
		objs = transAn.matchData();
		// 判断objs数组是否是配置物流数组
		if (objs instanceof MatchedTransport[]) {
			// 将对象数组强制类型转换成配置物流数组
			MatchedTransport[] matchTrans = (MatchedTransport[]) objs;
			// 输出匹配的物流信息
			tranService.showMatchTransport(matchTrans);
		}
	}

}
