package com.qst.dms.exception;

public class DataAnalyseException extends Exception {
	public DataAnalyseException() {

	}

	public DataAnalyseException(String msg) {
		super(msg);
	}
}
